/* frontend */

// -login
//   -user
//   -password
// -dashboard
//   -chatrooms
// -messages
//   -array of messages
// -enter messages
//   -input
// -websockets
//   -emit when message is sent
//   -listen to when response comes back from server

/* backend */

// -server
//   -getMessages
//   -postMessage
// -database
//   -users, chatrooms
// -websockets
//   -listen to when messages are sent from client
//      -save to database
//      -emit back to client
