module.exports = function(value) {
  this.value = value;
  this.next = null;
};