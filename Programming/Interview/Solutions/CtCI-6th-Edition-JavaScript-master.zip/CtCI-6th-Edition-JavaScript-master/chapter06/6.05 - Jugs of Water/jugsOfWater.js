// i)   Fill 5-quart jug
// ii)  Pour from 5-quart jug to 3-quart jug (5-quart will now have 2 quarts inside)
// iii) Empty 3-quart jug
// iv)  Pour from 5-quart jug to 3-quart jug (3-quart will now have 2 quarts)
// v)   Fill 5-quart jug
// vi)  Pour from 5-quart jug to 3-quart. be careful not to spill!
// vii) 5-quart jug will now have 4-quarts of water!