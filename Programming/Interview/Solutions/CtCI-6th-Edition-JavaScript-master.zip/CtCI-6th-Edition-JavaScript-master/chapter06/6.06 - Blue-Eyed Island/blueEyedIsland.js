// 1 person:  sees no one having blue eyes, leaves the next day (1 day)
// 2 persons: sees one other person having blue eyes, waits for a day
//            realises that he/she is not leaving, and hence there must be another 
//            blue-eye which is him/herself. hence leaves the following day (2 days)
// 3 persons: sees 2 other persons, waits for 2 days since they should realise by then,
//            if they still do not leave, will realise that there is one more person and
//            will leave on the following day (3 days)
//            ...
// n persons: will leave in n days