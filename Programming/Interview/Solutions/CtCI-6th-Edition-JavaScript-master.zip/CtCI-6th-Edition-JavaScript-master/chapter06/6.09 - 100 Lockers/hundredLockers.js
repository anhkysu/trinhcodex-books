// Step 1: reduce the problem into 2 doors -> door 1
// Step 2: 3 doors -> door 1
// Step 3: 4 doors -> doors 1, 4
// Step 4: 5 doors -> doors 1, 4
// Step 5: 6 doors -> doors 1, 4, 9
//              ...
// 100 doors -> doors, 1, 4, 9, 16, 25, 36, 49, 64, 81, 100

// all the square numbers are left open -> 10 doors are left open