// sort numbers
// stream through numbers and print elements which is a duplicate of the immediate previous number
