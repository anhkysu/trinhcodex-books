// Break up files into files containing one line each
// Iterate through files two by two and merge them
// Keep merging until there is one file
// If there are multiple threads, can dispatch them as multiple jobs to merge files together

